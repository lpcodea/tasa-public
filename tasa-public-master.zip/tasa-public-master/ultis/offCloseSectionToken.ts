import axios from "axios";


export const offCloseSectionToken = async () => {
    localStorage.clear();
    localStorage.removeItem("authTokenPublic");
    delete axios.defaults.headers.common['Authorization'];
    return window.location.href = '/login';
}
