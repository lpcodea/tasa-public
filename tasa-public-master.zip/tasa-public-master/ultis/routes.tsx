import { BsBox } from 'react-icons/bs';
import { HiOutlineBuildingOffice2 } from 'react-icons/hi2';


export const routes: any[] = [
    {
        label: 'Categorias',
        icon: <BsBox/>,
        src:"/categorias"
    },
    {
        label: 'Oficinas',
        icon: <HiOutlineBuildingOffice2/>,
        src:"/oficinas"
    }
]

