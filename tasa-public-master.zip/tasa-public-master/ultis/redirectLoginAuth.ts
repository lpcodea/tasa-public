

const redirectLoginAuth = () => {
    if (global.window?.location.pathname !== '/login'
        && global.window?.localStorage.getItem('authTokenPublic') === null
        || global.window?.localStorage.getItem('authTokenPublic') === undefined){
        return global.window ? global.window.location.href = '/login' : null
    }

}

export default redirectLoginAuth;
