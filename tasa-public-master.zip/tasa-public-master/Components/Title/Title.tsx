import React from 'react'
import style from '../Title/Title.module.scss'
import {IoIosLogIn} from 'react-icons/io';
import Link from 'next/link';
import { offCloseSectionToken } from '@app/ultis/offCloseSectionToken';


interface ITitleParams {
    titleView?: string;
    description?: string;
    iconBox?: any;
}


export default function Title(props: ITitleParams) {
  return (
    <div className={style.contentHeader}>
          <div className={style.log}>
                <i> <IoIosLogIn/></i>
                <Link href='/login'>
                    <p onClick={offCloseSectionToken}>Cerrar sesion</p>
                </Link>
            </div>

            <div className={style.contentText}>
                    <h3 className='mb-3'>¡Tasa de Rendimiento!</h3>
                    <p>
                        En este portal podrá visualizar nuestras opciones de inversión y rendimientos actualizados.<br/>
                        Favor considerar que estos rendimientos son indicativos y sujetos a disponibilidad en <br/>cuanto a plazo,
                        monto e instrumento.
                    </p>


                  <Link target="_blank" href="https://www.parval.com.do/contactanos/">
                    <p className={style.badgeHeader}>
                      Contacto
                    </p>
                  </Link>
            </div>

    </div>
  )
}
