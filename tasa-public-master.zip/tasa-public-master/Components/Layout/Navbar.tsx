import React from 'react'
import { useState } from 'react';
import Image from 'next/image';
import  style from '../Layout/Layout.module.scss';
import ModalCategory from '../modals/ModalCategory';
import { routes } from '@app/ultis/routes';
import Link from 'next/link';

export default function Navbar() {

  const [show, setShow] = useState(false);

  return (
      <>
        <div className={style.Navbar}>
            <Link href={'/categorias'}>
                <div className={style.logo}>
                    <div className={style.img}>
                      <Image
                          priority
                        src={"/logo_horizon.svg"}
                        alt={"logo Parval"}
                        width={160}
                        height={95}
                      />
                    </div>
                </div>
            </Link>
            <div className={style.boxLine}>
              <hr/>
            </div>
            <p>Menu</p>
            {/* Category List */}
            <div className={style.wrapper}>
                <ul>
                  {
                    routes && routes.map((item: any, index) => (
                        <>
                            <li key={index}>
                                <Link href={item.src}>
                                    <i>{item.icon}</i> &nbsp;
                                    {item.label}
                                </Link>
                            </li>
                        </>
                    ))
                  }
                </ul>
            </div>

            <div className={style.footerBar}>
               <p>© 2023 Parval</p>
            </div>

            <ModalCategory show={show} handleClose={() => setShow(!show)} />
        </div>
      </>
  )
}
