import React from 'react'
import { useState } from 'react';
import {GiHamburgerMenu} from 'react-icons/gi';
import  style from '../Layout/Layout.module.scss';
import {routes} from '../../ultis/routes';
import Link from 'next/link';

export default function NavbarMobil() {
    const [show, setShow] = useState(false);

    const handleShow = () => setShow(!show);

  return (
      <>
          <div className={style.navMobil}>
              {
                  show &&
                  <div className={style.contentItemMobil}>
                      <ul>
                          {
                              routes && routes.map((item,index) =>{
                                  return <li key={index}> <i>{item.icon}</i>&nbsp; <Link href={item.src} >{item.label}</Link></li>
                              })
                          }
                      </ul>
                  </div>
              }

              <i className={style.iconMobil} onClick={handleShow}>
                  <GiHamburgerMenu />
              </i>
          </div>
      </>
  )
}
