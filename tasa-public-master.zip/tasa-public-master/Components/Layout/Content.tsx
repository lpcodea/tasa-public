import React from 'react'
import  style from '../Layout/Layout.module.scss';

export default function Content() {
  return (
    <>
        <div className={style.Content}>
            <div className={style.contentWrapper}>
                <div className={style.tabs}>
                    <h2>Hello Leonardo perez</h2>
                </div>
            </div>
        </div>
    </>
  )
}
