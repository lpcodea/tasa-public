import { offCloseSectionToken } from '@app/ultis/offCloseSectionToken';
import React from 'react'
import  style from '../Layout/Layout.module.scss';

export default function Header() {
  return (
      <>
          <div className={style.Header }>
              <div className={style.headWrapper}>
                  <div className={style.title}>
                      <h2>Hello, <span>Leo!</span></h2>
                      <p>Welcome to board</p>
                  </div>
              </div>

              <div className={style.log}>
                  <button onClick={offCloseSectionToken}>Cerrar sesion</button>
              </div>
          </div>
      </>
  )
}
