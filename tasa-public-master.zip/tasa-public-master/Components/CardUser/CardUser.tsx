import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Image } from 'react-bootstrap'
import { AiOutlineMail } from 'react-icons/ai';
import { BsTelephone } from 'react-icons/bs';
import style from '../CardUser/CardUser.module.scss';


interface ICardUser {
  name?: string;
  position?: string;
  phone?: string;
  mail?: string;
  image?: string;
}


export default function CardUser(props: ICardUser) {

  return (
    <>
      <div className={style.card}>
        {/* profile picture */}
        <div className={style.profile}>
          <Image
              style={{ width: "80px", height: "80px"}}
              src={props.image ? props.image : "/profile.jpg"}
              alt="Imagen"
              roundedCircle />
        </div>
        {/* name text */}
        <div className={style.text}>
          <p>{props.name}</p>
          <span>{props.position}</span>
        </div>
        <hr/>
        {/* info contact */}
        <div className={style.info}>
          <p><i><BsTelephone/></i> {props.phone}</p>
          <p><i><AiOutlineMail/></i> {props.mail}</p>
        </div>
      </div>

    </>
  )
}
