import React from 'react'
import { AiOutlineEye } from 'react-icons/ai';
import { AiOutlineDelete } from 'react-icons/ai'
import style from '../ItemList/ItemList.module.scss'
import { useState } from 'react';
import Link from 'next/link';
import ModalDelete from '../modals/ModalDelete';

interface ItemListProps {
    list?: any[];
}

export default function ItemList(props: ItemListProps) {
    const [show, setShow] = useState(false);

  return (
    <>
        {
            !!props.list &&
                props.list.map((item: any) => (
                    <>
                        <div className={style.content}>
                            <div className={style.item}>
                                <div className={style.name}>
                                    <p>{ item.name }</p>
                                </div>
                                <div className={style.iconsGroup}>
                                    <div className={style.icon}>
                                        <i> <AiOutlineEye/> </i>
                                    </div>
                                </div>
                            </div>
                            <hr/>
                        </div>
                    </>
                ))
        }

    </>
  )
}
