import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Image from 'next/image';
import style from '../bannerOffcie/bannerOffice.module.scss';

interface IBannerOfficeProps {
    bankgroup?: any;
}


export default function BannerOffice(props: IBannerOfficeProps) {
  return (
    <>
    <div className={style.content}>
        <div className={style.text}>
            <h1>Oficinas</h1>
            {/* <span>Ave. Abrahan Lincoln 1057 Edificio Mil57 Piso, Serralles, Santo Domingo 10129</span> */}
        </div>

        <div className={style.imgContent}>
            <div className={style.imgBox}>
            <Image
                priority
                  src={props.bankgroup}
                  alt={"imagen de finzas"}
                  width={320}
                  height={130}
                />
            </div>
        </div>
    </div>
    </>
  )
}
