import React from 'react'
import { HiOutlineBuildingOffice2 } from 'react-icons/hi2';
import style from '../BadgeUi/BadgeUi.module.scss';

export default function BadgeUi(props: { itemName?: any }) {

  return (
      <>
          <div className={style.boxBadge}>
              <span className={style.badge}>
               <i><HiOutlineBuildingOffice2 /></i> &nbsp;
               {props.itemName
            }</span>
          </div>
      </>
  )
}
