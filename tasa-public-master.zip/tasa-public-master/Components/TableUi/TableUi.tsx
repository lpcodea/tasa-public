import React from 'react';
import { Table } from 'react-bootstrap';
import style from '../TableUi/TableUi.module.scss';

interface IInfoTable {
  description: string;
  name: string;
  table: any;
}

export default function TableUi(props: IInfoTable) {

  return (
    <>
      <div  className={style.tableContent}>

          <div className={style.descriptionTab}>
              <h5> { props.name } </h5>
              <p>
                  {
                    props.description
                  }
              </p>
          </div>

          <Table responsive="lg">
          <thead>
            <tr className={style.HeaderTab}>
              {
                props?.table?.table.headers && props?.table?.table?.headers.map((item: any) => {
                    return (
                        <th key={item.id}> { item.name } </th>
                    )
                })
              }
            </tr>
          </thead>
          <tbody>
                {
                   props.table.table.data && props.table.table.data.map((item: any) => (
                       <tr key={item.id} className={style.gridTab}>
                           {
                               props.table.table.headers && props.table.table.headers.map((index: any) => (
                                   <td key={index.id}>{ item[index.name] } </td>
                               ))
                           }
                       </tr>
                   ))

                }
          </tbody>
        </Table>
      </div>
    </>
  )
}
