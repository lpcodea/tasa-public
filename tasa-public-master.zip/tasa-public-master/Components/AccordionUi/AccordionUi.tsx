import React from 'react'
import { Accordion } from 'react-bootstrap';
import style from '../AccordionUi/AccordionUi.module.scss';
import ItemList from '../ItemList/ItemList';
import Link from 'next/link';

interface AccodionUiProps {
    accordionName: string;
}


export default function AccodionUi(props: AccodionUiProps) {

  return (
    <>
      <Accordion>
        <Accordion.Item className={style.accordionItem} eventKey="0">
            <Accordion.Header>{props.accordionName}</Accordion.Header>
            <Accordion.Body>
              <div className={style.ListUi}>
                <div className={style.badgeProduct}>
                  <Link href='/producto'>
                     <center>Nuevo producto</center>
                  </Link>
                </div>
                  <ItemList
                    list={[{name: "Sell-Buy-Back (SBB)"}]}
                  />
              </div>
            </Accordion.Body>
        </Accordion.Item>
       </Accordion>
    </>
  )
}
