import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Modal } from 'react-bootstrap';
import style from '../modals/ModalCategory.module.scss';

interface IModalComponent {
    children: any;
    title: string;
    show: boolean;
    size?: 'sm' | 'lg' | 'xl';
    colorButton?: 'primary' | 'danger';
    handleActions?: any;
    nameActions?: string;
    handleClose?: any;
}

export default function ModalComponent(props: IModalComponent) {

    return (
        <>
            <Modal
                aria-labelledby="contained-modal-title-vcenter"
                centered
                size={props.size ? props.size : 'sm'}
                show={props.show} onHide={props.handleClose}>
                <Modal.Header  className={style.headelModal} closeButton>
                    <Modal.Title className={style.title}>
                        <p>{ props.title }</p>
                    </Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    {
                        props.children
                    }
                </Modal.Body>

                <Modal.Footer  className={style.footerModal}>
                    <Button style={{
                        color: 'white',
                        fontSize: '15px',
                        border: 'solid 0',
                        width: '100%',
                        padding: '18px',
                    }} className={props.colorButton ? props.colorButton : 'primary'}
                            onClick={ () => {
                                props.handleActions()
                                props.handleClose()
                            }}>
                        {
                            props.nameActions
                        }
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}
