import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import style from '../modals/ModalCategory.module.scss';
import BadgeUi from '../BadgeUi/BadgeUi';
import { Col, Row, Button, Modal } from 'react-bootstrap';


export default function ModalGridTab (props: {show: boolean, handleClose: any}) {

  return (
   <>
       <Modal
           aria-labelledby="contained-modal-title-vcenter"
           centered
           show={props.show} onHide={props.handleClose}>
           <Modal.Header  className={style.headelModal} closeButton>
               <Modal.Title className={style.title}>
                   <p>Configurar Estructura</p>
               </Modal.Title>
           </Modal.Header>

           <Modal.Body>
               <div className={style.bodyModal}>
                   <div className={style.contentBadge}>
                       <Row>
                           <Col className='mb-4' lg={6}>
                               <BadgeUi
                                   itemName="Moneda"
                               />
                           </Col>

                           <Col className='mb-4' lg={6}>
                               <BadgeUi
                                   itemName="60 Dias"
                               />
                           </Col>
                       </Row>
                   </div>
               </div>
           </Modal.Body>

           <Modal.Footer  className={style.footerModal}>
               <Button className={style.btnStyle} variant="primary" onClick={props.handleClose}>
                   Guardar
               </Button>
           </Modal.Footer>

       </Modal>
   </>
  )
}
