import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Row, Col, Form, Modal } from 'react-bootstrap';
import style from '../modals/ModalCategory.module.scss';

export default function formOperation(props: { show: any, handleClose: any }) {

  return (
    <>
        <Modal
            size={'sm'}
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.show} onHide={props.handleClose}>
            <Modal.Header  className={style.headelModal} closeButton>
                <Modal.Title className={style.title}>
                    <p>
                        Nueva Operacion
                        <br />
                        {/* Description */}
                        <span>
                          Sell-Buy-Back (SBB)
                        </span>
                    </p>

                </Modal.Title>
            </Modal.Header>

            <Modal.Body>

                {/* Body form */}
                <div className={style.bodyModal}>
                    <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                        <span>Tipo de moneda</span>
                        <Form.Control className={style.input} type="text" placeholder="Escribir nombre de categoria" />
                    </Form.Group>

                    <Row>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-1" controlId="exampleForm.ControlInput1">
                                <span>60 Días</span>
                                <Form.Control className={style.input} type="text"/>
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-1" controlId="exampleForm.ControlInput1">
                                <span>90 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                                <span>120 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                                <span>150 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                                <span>180 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                                <span>210 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                                <span>270 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                        <Col xs={12} md={6}>
                            <Form.Group className="mt-2 mb-2" controlId="exampleForm.ControlInput1">
                                <span>360 Días</span>
                                <Form.Control className={style.input} type="text" />
                            </Form.Group>
                        </Col>
                    </Row>


                </div>
            </Modal.Body>

            <Modal.Footer  className={style.footerModal}>
                <Button className={style.btnStyle} variant="primary" onClick={props.handleClose}>
                    Agregar
                </Button>
            </Modal.Footer>

        </Modal>
    </>
  )
}
