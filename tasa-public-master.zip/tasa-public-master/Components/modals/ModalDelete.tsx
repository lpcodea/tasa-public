import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Form, Modal } from 'react-bootstrap';
import style from '../modals/ModalCategory.module.scss';

interface IModalDeleteInterface {
    show: boolean;
    handleClose: any;
    NameDelete: string;
    onHandleClose?: any;
}

export default function ModalDelete(props: IModalDeleteInterface) {

  return (
      <>

          <Modal
              aria-labelledby="contained-modal-title-vcenter"
              centered
              show={props.show} onHide={props.handleClose}>
              <Modal.Header  className={style.headelModal} closeButton>
                  <Modal.Title className={style.title}>
                      <p>¿ Quieres eliminar ?</p>
                  </Modal.Title>
              </Modal.Header>

              <Modal.Body>
                  <div className={style.bodyModal}>
                      <Form.Group className="mt-4 mb-4" controlId="exampleForm.ControlInput1">
                          <span>Nombre:</span>
                          <h6 className='mt-2'>{props.NameDelete}</h6>
                      </Form.Group>
                  </div>
              </Modal.Body>

              <Modal.Footer  className={style.footerModal}>
                  <Button className={style.btnDelete} variant="primary" onClick={props.onHandleClose}>
                      Eliminar
                  </Button>
              </Modal.Footer>

          </Modal>
      </>
  )
}
