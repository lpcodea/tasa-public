import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Form, Modal } from 'react-bootstrap';
import style from '../modals/ModalCategory.module.scss';
import { BsBox } from 'react-icons/bs';

export default function ModalNewProduct(props: {show: boolean, handleClose: any}) {
  return (
      <>
          <Modal
              aria-labelledby="contained-modal-title-vcenter"
              centered
              show={props.show} onHide={props.handleClose}>
              <Modal.Header  className={style.headelModal} closeButton>
                  <Modal.Title className={style.title}>
                      <i><BsBox/></i>
                      <p>Agregar nueva categoria</p>
                  </Modal.Title>
              </Modal.Header>

              <Modal.Body>
                  <div className={style.bodyModal}>
                      <Form.Group className="mt-4 mb-4" controlId="exampleForm.ControlInput1">
                          <span>Nombre de la categoria</span>
                          <Form.Control className={style.input} type="email" placeholder="Escribir nombre de categoria" />
                      </Form.Group>
                  </div>
              </Modal.Body>

              <Modal.Footer  className={style.footerModal}>
                  <Button className={style.btnStyle} variant="primary" onClick={props.handleClose}>
                      Agregar Categoria
                  </Button>
              </Modal.Footer>

          </Modal>
      </>
  )
}
