import { useDispatchCategories } from "./StoreProvider";
import { TypesCategories } from './CategoriesTypes';
import urlApi from './../../dataApi/urlApis';
import { getAll } from "../methods";

export function useCategories() {
    const dispatch = useDispatchCategories();
    return {
        async getAllCategories() {
            const categories: any = await getAll(`${urlApi}/list-category`);
            dispatch({
                type: TypesCategories.GET_CATEGORIES,
                payload: {
                    categories,
                },
            });
        },
    }
}
