import { useDispatchAuthLogin } from "./StoreProvider";
import { TypesAuthLogin } from './authLoginTypes';
import jwt from 'jwt-decode';
import urlApi from './../../dataApi/urlApis';
import { postAll } from "../methods";
import { setAuthorizationToken } from './../../ultis/setAuthorizationToken';

interface IUsersLogin {
    username: string;
    password: string;
}

export interface IDataUsersLoggers {
    "id": number | string;
    "name": string;
    "username": string;
}


export function useAuthLogin() {
    const dispatch = useDispatchAuthLogin();
    return {
        async postAuthLogin(dataUsers: IUsersLogin){

            try {
                const authLogin: any = (await postAll(`${urlApi}/login-public`, dataUsers)).data;
                localStorage.setItem('authTokenPublic', authLogin);
                setAuthorizationToken(authLogin);
                return authLogin;
            } catch (e){
                return {
                    code: 400,
                    message: 'Invalid password',
                    name: 'NotFound',
                }
            }
        },
        getAuthLogin() {
            if (global.window?.localStorage.authTokenPublic){
                const authLogin : any = localStorage.getItem('authTokenPublic');
                dispatch({
                    type: TypesAuthLogin.GET_AUTHLOGIN,
                    payload: {
                        authLogin: jwt(authLogin) as IDataUsersLoggers,
                    },
                });
            }
        }
    }
}
