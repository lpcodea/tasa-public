import { useDispatchBranchOffices } from "./StoreProvider";
import { TypesBranchOffices } from './branchOfficesTypes';
import urlApi from './../../dataApi/urlApis';
import { getAll } from "../methods";

export function useBranchOffices() {
    const dispatch = useDispatchBranchOffices();
    return {
        async getAllBranchOffices(){
            const branchOffices: any = await getAll(`${urlApi}/list-brand-offices`);
            dispatch({
                type: TypesBranchOffices.GET_BRANCHOFFICES,
                payload: {
                    branchOffices: branchOffices,
                },
            });
        },
    }
}
