import { createContext, useContext, useReducer } from 'react';
const StoreContextBranchOffices = createContext<any | null>(null);
import { TypesBranchOffices } from './branchOfficesTypes';

function StoreReducerBranchOffices(state: any, action: any){
    const { type, payload } = action;
    switch (type) {
        case TypesBranchOffices.GET_BRANCHOFFICES:
            return {
                ...state,
                branchOffices: payload.branchOffices
            };
        default:
            return state;
    }
}

const inicialState : any = {
    branchOffices: [],

}


export default function StoreProviderBranchOffices({ children } : any) {

    const [ store, dispatch ] = useReducer(StoreReducerBranchOffices, inicialState);

    return (
        <StoreContextBranchOffices.Provider value={[store, dispatch]}>
            {
                children
            }
        </StoreContextBranchOffices.Provider>
    )
}

const useStoreBranchOffices = () => useContext(StoreContextBranchOffices)[0];
const useDispatchBranchOffices = () => useContext(StoreContextBranchOffices)[1];

export { StoreContextBranchOffices, useDispatchBranchOffices, useStoreBranchOffices, TypesBranchOffices };


