const TypesBranchOffices = {
    GET_BRANCHOFFICES: 'GET_BRANCHOFFICES',
}

function BranchOfficesTypes(state: any, action: any){
    const { type, payload } = action;
    switch (type) {
        case TypesBranchOffices.GET_BRANCHOFFICES:
            return {
                ...state,
                branchOffices: payload.branchOffices
            };
        default:
            return state;
    }
}
export { TypesBranchOffices };
export default BranchOfficesTypes;
