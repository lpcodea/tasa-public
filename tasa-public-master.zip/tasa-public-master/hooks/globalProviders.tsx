import React from "react";
import StoreProviderBranchOffices from "./BranchOffices/StoreProvider";
import StoreProviderCategories from "./Categories/StoreProvider";

export default function GlobalProviders({ children } : any) {
    return (
        <>
            <StoreProviderCategories>
               <StoreProviderBranchOffices>
                   {
                     children
                   }
               </StoreProviderBranchOffices>
            </StoreProviderCategories>
        </>
    )
}
