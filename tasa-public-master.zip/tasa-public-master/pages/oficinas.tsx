import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import style from '../styles/ejecutivoList.module.scss';
import BannerOffice from '@app/Components/bannerOffcie/bannerOffice';
import BadgeUi from '@app/Components/BadgeUi/BadgeUi';
import CardUser from '@app/Components/CardUser/CardUser';
import { Row, Col } from 'react-bootstrap';
import { useBranchOffices } from '@app/hooks/BranchOffices';
import { useStoreBranchOffices } from '@app/hooks/BranchOffices/StoreProvider';


export default function Oficinas() {

    const { getAllBranchOffices } : any = useBranchOffices();
    const [ offices, setOffices]  : any = useState(0);
    const [businessTeam, setBusinessTeam]: any = useState([]);

    useEffect(() => {
        getAllBranchOffices()
    }, []);

    const { branchOffices } = useStoreBranchOffices();

    useEffect(() => {
        if (branchOffices.length) {
            branchOffices.map((item: any) => {
                if (item.businessTeam.length){
                    setBusinessTeam(item.businessTeam);
                }
            })
        }
    }, [branchOffices])

    useEffect(() => {
        if (branchOffices.length) {
            const team = branchOffices.find((item: any) => item.id === offices);
            if (team?.businessTeam){
                setBusinessTeam(team.businessTeam)
            }

        }
    }, [offices])

    console.log(branchOffices);
  return (
    <>
      <BannerOffice
        bankgroup={'/agentGroup.png'}
      />

      <div className={style.container}>
        <div className={style.ListOffcie}>
            {
                !!branchOffices &&
                    branchOffices.map((item: any) => {
                        return (
                            <div key={item.id} onClick={() => setOffices(item.id)}>
                                <BadgeUi
                                    itemName={item.name}
                                />
                            </div>
                        )
                    })
            }
        </div>

        <div className={style.cardContent}>

          <Row>
              {
                  businessTeam.length ?
                    businessTeam.map((item: any) => (
                        <Col key={item.id} className={style.col} lg={3} md={6}>
                            <CardUser
                                name={item.name}
                                position={item?.businessRoles?.name}
                                phone={item.phone ? `${item.phone ? item.phone : ''} ${item.ext ? item.ext : ''}` : item.mobile}
                                mail={item.email}
                                image={item.image}
                            />
                        </Col>
                    )) : null
              }
          </Row>
        </div>
      </div>
    </>
  )
}
