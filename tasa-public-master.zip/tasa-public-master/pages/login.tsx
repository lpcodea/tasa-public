import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Row, Col, Button} from 'react-bootstrap';
import styles from '../styles/Login.module.scss';
import Image from 'next/image';
import { FaUserLock } from 'react-icons/fa';
import { useAuthLogin } from "../hooks/AuthLogin";

interface IUsersLogin {
    password: string;
}

export default function Login() {

    const { postAuthLogin } : any = useAuthLogin();

    const [DataUserLogin, setDataUserLogin] = useState({
        password: ''
    });

    const [ dataResponse, setDataResponse ]: any = useState({});

    const { password } = DataUserLogin;

    const onHandleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        const {name, value} = e.target;
        setDataUserLogin(DataUserLogin => ({...DataUserLogin, [name]: value}))
    }

    useEffect(() => {
      const handleKeyPress = (event: KeyboardEvent) => {
        if (event.key === 'Enter') {
          const button = document.getElementById('submit-btn');
          if (button) {
            button.click();
          }
        }
      };
    
      document.addEventListener('keydown', handleKeyPress);
    
      return () => {
        document.removeEventListener('keydown', handleKeyPress);
      };
    }, []);

    const checkLogin = async () => {
        const dataUser: IUsersLogin = {
            password
        }

        await postAuthLogin(dataUser).then((res: any) => {
            setDataResponse(res);
            if (res?.code !== 400){
                if (localStorage.getItem('authTokenPublic') !== undefined) {
                    window.location.href = '/categorias'
                }
            }
        });
    }

  return (
    <>
      <Row>
        {/* Colum vectors and text */}
        <Col lg={6}>
          <div className={styles.boxVector}>
           <div className={styles.titleCont}>
              <h1>Tasas de Rendimiento</h1>
              {/* <p>Portal Administrativo</p> */}
           </div>

           <div className={styles.vector}>
            <Image
                priority
                  src={'/person.svg'}
                  alt={"imagen de finzas"}
                  width={500}
                  height={500}
                />
           </div>
             <p className={styles.textFooter}>Miembro de la Bolsa de Valores de la República Dominicana S. A.</p>
          </div>
        </Col>

        {/* Colum form */}
        <Col className={styles.colForm} lg={6}>
          <div className={styles.boxForm}>

            <div className={styles.img}>
              <Image
                  priority
                src={'/logoParval.svg'}
                alt={"logo de parval"}
                width={150}
                height={150}
              />
            </div>
            <div className={styles.inputGroup}>
              {/* input Password*/}
              <Form.Group className="mb-3">
                <span> <i><FaUserLock/></i>Contraseña</span>
                <Form.Control
                    className={styles.input}
                    onChange={onHandleInput}
                    name={'password'}
                    type={'password'}
                    placeholder="Contraseña"
                />
              </Form.Group>
                {
                    dataResponse?.code !== 400 ? null
                        : <div className={'t-1 text-xs text-red-600'}>
                            <span>{ dataResponse?.message ? dataResponse?.message : 'Invalid password' }</span>
                        </div>
                }

              <Button
                  className={`w-100 p-4 ${styles.btnPrimary} ${ password === '' || password === undefined ? 'bg-light' : '' }`}
                  disabled={password === '' || password === undefined}
                  onClick={checkLogin}
                  variant="primary"
                  id={'submit-btn'}
                  size="lg"
              >
                  Iniciar sesión
              </Button>
            </div>
          </div>
        </Col>
      </Row>
    </>
  )
}
