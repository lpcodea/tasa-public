import React, { useState, useEffect } from 'react'
import { Tab, Tabs } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import style from '../styles/categorias.module.scss';
import TableUi from '@app/Components/TableUi/TableUi';
import Title from '@app/Components/Title/Title';
import { useCategories } from '@app/hooks/Categories';
import { useStoreCategories } from '@app/hooks/Categories/StoreProvider';

export default function Categorias() {
    const { getAllCategories }: any = useCategories();

    useEffect(() => {
        getAllCategories()
    }, [])

    const { categories } : any = useStoreCategories();

  return (
   <>
    <Title/>
        <div className='p-3'>
            <div className={style.content}>
                <Tabs
                    defaultActiveKey="profile"
                    justify
                    >

                                {
                                    categories.length ?
                                        categories.map((item: any, index: number) => (
                                                    <Tab key={item.id} eventKey={index ? `profile-${index}` : 'profile'}  title={item.name}>
                                                        <div className={style.contentTab}>
                                                            {
                                                                item.products ?
                                                                    <>
                                                                        {
                                                                            item.products.map((item: any) => (
                                                                                <>
                                                                                    <TableUi
                                                                                        table={item.table}
                                                                                        description={item.description}
                                                                                        name={item.name}
                                                                                    />
                                                                                </>
                                                                            ))
                                                                        }
                                                                    </> : <>
                                                                        <div> No hay Productos disponibles para vista </div>
                                                                    </>
                                                            }
                                                        </div>
                                                    </Tab>
                                            )) : <Tab eventKey={'profile'} title={''}><div> No hay Categorias disponibles para vista </div></Tab>
                                }
                </Tabs>
            </div>
        </div>
   </>
  )
}
