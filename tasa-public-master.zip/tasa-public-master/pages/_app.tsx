import Layout from '@app/Components/Layout/Layout';
import StoreProviderAuthLogin from '@app/hooks/AuthLogin/StoreProvider';
import GlobalProviders from '@app/hooks/globalProviders';
import '@app/styles/globals.css';
import redirectLoginAuth from '@app/ultis/redirectLoginAuth';
import { setAuthorizationToken } from '@app/ultis/setAuthorizationToken';
import type { AppProps } from 'next/app';
import React from 'react';
import Login from './login';
import { useState, useEffect } from 'react';
import { useRouter } from "next/router";

setAuthorizationToken(global.window?.localStorage.authTokenPublic);
redirectLoginAuth();

export default function App({ Component, pageProps }: AppProps) {
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const handleStart = (url: any) => {
            url !== router.pathname ? setLoading(true) : setLoading(false);
        };
        
        if (router.pathname === '/'
            || router.pathname === '/login' || router.pathname === '/_error'
            && !global.window?.localStorage.AuthToken) {
                router.push('/categorias')
        }

        const handleComplete = (url: any) => setLoading(false);

        router.events.on("routeChangeStart", handleStart);
        router.events.on("routeChangeComplete", handleComplete);
        router.events.on("routeChangeError", handleComplete);

    }, [router]);
  return (
      <>
          <StoreProviderAuthLogin>
              {
                  global.window?.localStorage.authTokenPublic ?
                      (<>
                          <Layout>
                              <GlobalProviders>
                                  <Component {...pageProps} />
                              </GlobalProviders>
                          </Layout>
                      </>) : <Login />
              }
          </StoreProviderAuthLogin>
      </>
  )
}
