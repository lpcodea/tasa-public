const urlApi = 'http://tasa.southcentralus.cloudapp.azure.com:8001';
// const urlApi = 'http://localhost:8001';

export default urlApi;
